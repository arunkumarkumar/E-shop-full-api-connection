package com.eshop.model;

import jakarta.persistence.*;

@Entity

public class UserDetails {
	

   private int userId;
   private int pin;
   private Cart cartAdd;
  public Cart getCartAdd() {
	return cartAdd;
}
public void setCartAdd(Cart cartAdd) {
	this.cartAdd = cartAdd;
}

public int getUserid() {
	return userId;
}
public void setUserid(int userId) {
	this.userId = userId;
}
public int getPin() {
	return pin;
}
public void setPin(int pin) {
	this.pin = pin;
}


}
