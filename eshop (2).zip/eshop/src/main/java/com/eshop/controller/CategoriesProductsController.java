package com.eshop.controller;

import java.util.List;

import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eshop.dao.AddtoCartqueries;
import com.eshop.dao.CategoryProductsquery;
import com.eshop.model.ApiResponse;
import com.eshop.model.CartDetails;
import com.eshop.model.Categories;
import com.eshop.model.ProductDetails;
@RestController
@RequestMapping("/api")
public class CategoriesProductsController {
	@Autowired
	CategoryProductsquery query;
	@Autowired
	AddtoCartqueries queriies;
	Logger logger=org.apache.logging.log4j.LogManager.getLogger("E-Shopping");
	@GetMapping("/category")
	public ApiResponse categoryDetails(){
		logger.info("Category Api");
		ApiResponse apiResponse_Pojo=new ApiResponse();
		try {
		List<Categories> categoryDetails = query.category();
		if(categoryDetails==null) {
			logger.warn("Categorydetails are null");
			apiResponse_Pojo.setMessage("Categorydetails are null");
			apiResponse_Pojo.setHttpStatus(HttpStatus.BAD_REQUEST.value());
			JSONObject jsonObject = new JSONObject();
			apiResponse_Pojo.setResponseData(jsonObject);
			return apiResponse_Pojo;
		}
		else {
			logger.warn("List of Categories");
			apiResponse_Pojo.setMessage("List of Categories");
			apiResponse_Pojo.setHttpStatus(HttpStatus.FOUND.value());
			apiResponse_Pojo.setResponseData(new JSONObject().put("List of Categories", categoryDetails));
			return apiResponse_Pojo;
		}
	}
		catch (Exception e) {
			 logger.warn("Exception Occured");
		     apiResponse_Pojo.setMessage("Exception Occured");
		     apiResponse_Pojo.setHttpStatus(HttpStatus.BAD_GATEWAY.value());
		     return apiResponse_Pojo;
		}
	}
	@GetMapping("/listofproducts")
	public ApiResponse categoryChose(@RequestParam (value ="categories") String choicecategory){
		logger.info("ListOfproducts");
		ApiResponse apiResponse_pojo=new ApiResponse();
		try {
		List<ProductDetails> productDetails = query.products(choicecategory);
		if(productDetails==null) {
			logger.warn("Listofproducts is null");
			apiResponse_pojo.setMessage("Listofproducts is null");
			apiResponse_pojo.setHttpStatus(HttpStatus.BAD_REQUEST.value());
			JSONObject jsonObject = new JSONObject();
			apiResponse_pojo.setResponseData(jsonObject);
			return apiResponse_pojo;
		}else {
			logger.warn("List of products");
			apiResponse_pojo.setMessage("List of products");
			apiResponse_pojo.setHttpStatus(HttpStatus.FOUND.value());
			apiResponse_pojo.setResponseData(new JSONObject().put("List of Products", productDetails));
			Categories cate=new Categories();
			cate.setListofproducts(productDetails);
			return apiResponse_pojo;
		}	
	}
	catch (Exception e) {
		 logger.warn("Exception Occured");
	     apiResponse_pojo.setMessage("Exception Occured");
	     apiResponse_pojo.setHttpStatus(HttpStatus.BAD_GATEWAY.value());
	      return apiResponse_pojo;
	}
}
	@PostMapping("/addcart")
	public ResponseEntity<Object> addToCart(@RequestBody CartDetails products){
		String list=queriies.cartToAdd(products.getCartId(),products.getProduct(),products.getQuantity());
		
		return null;
		
	}
	
}
