package com.eshop.controller;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eshop.dao.UserandPinqueries;
import com.eshop.model.ApiResponse;
import com.eshop.model.UserDetails;
@RestController
@RequestMapping("/api")
public class UserContoller {
	@Autowired
	UserandPinqueries queries;
	Logger logger=org.apache.logging.log4j.LogManager.getLogger("E-Shopping");
	@GetMapping("/newuser")
	public ApiResponse addUsers(@RequestParam (value ="userId") int userId,@RequestParam (value="pin") int pin ){
		logger.info("add new user by userId and pin API");
		boolean newuser;
		ApiResponse apiResponse_pojo=new ApiResponse();
		try {
		UserDetails user = queries.getUserById(userId);
		if(user==(null)) {
			logger.warn("userdetails are null");
			apiResponse_pojo.setMessage("UserDetails are null");
			apiResponse_pojo.setHttpStatus(HttpStatus.BAD_GATEWAY.value());
			  JSONObject jsonObject = new JSONObject();
			    jsonObject.put("userId", userId);
			    apiResponse_pojo.setResponseData(jsonObject);
			return apiResponse_pojo;
		}
		else {
		if (user.getUserid() == userId) {
			logger.warn("This id is already taken");
			apiResponse_pojo.setMessage("This id is already taken");
			apiResponse_pojo.setHttpStatus(HttpStatus.BAD_REQUEST.value());
			  JSONObject jsonObject = new JSONObject();
			    jsonObject.put("userId", userId);
			    apiResponse_pojo.setResponseData(jsonObject);
			return apiResponse_pojo;
		}
		 else if (user.getUserid() != userId) {
			 if((String.valueOf(userId).length())==4) {
				 newuser=queries.newUser(userId,pin);
			 if(newuser==false) {
				 logger.warn("Problem in database Connection is null");
				 apiResponse_pojo.setMessage("Problem in database Connection is null");
				 apiResponse_pojo.setHttpStatus(HttpStatus.BAD_REQUEST.value());
				 return apiResponse_pojo;
			 }
			 else if(newuser==true) {
				    logger.warn("User Details Inserted");
				    apiResponse_pojo.setMessage("User Details Inserted ");
				    apiResponse_pojo.setHttpStatus(HttpStatus.CREATED.value());
				    JSONObject jsonObject = new JSONObject();
				    jsonObject.put("userId", userId);
				    jsonObject.put("pin", pin);
				    apiResponse_pojo.setResponseData(jsonObject);
					return apiResponse_pojo;
			 }
			 else {
				 return apiResponse_pojo;
			 }
		 }
		 else {
			 logger.warn("Userid number size is invalid");
			    apiResponse_pojo.setMessage(" this Userid number size is invalid ");
			    apiResponse_pojo.setHttpStatus(HttpStatus.BAD_REQUEST.value());
			    JSONObject jsonObject = new JSONObject();
			    jsonObject.put("userId", userId);
			    apiResponse_pojo.setResponseData(jsonObject);
			  return apiResponse_pojo;
			 }
		 }
		 else {
			 logger.warn("Invalid data and Response");
			    apiResponse_pojo.setMessage("Invalid data and Response ");
			    apiResponse_pojo.setHttpStatus(HttpStatus.EXPECTATION_FAILED.value());
			 return apiResponse_pojo;
		 }
			
		}
	}
		catch (Exception e) {
			     logger.warn("Exception Occured");
			     apiResponse_pojo.setMessage("Exception Occured");
			     apiResponse_pojo.setHttpStatus(HttpStatus.BAD_GATEWAY.value());
			     return apiResponse_pojo;
		}
	}
	@GetMapping("/existuser")
	public ApiResponse oldUser(@RequestParam (value ="userId") int userId,@RequestParam (value="pin") int pin ){
		logger.info("Exist user API");
		ApiResponse apiResponse_pojo=new ApiResponse();
		try {
			UserDetails user=queries.getUserById(userId);
			if(user==(null)) {
				logger.warn("userdetails response is null");
				apiResponse_pojo.setMessage("userdetails response is null");
				apiResponse_pojo.setHttpStatus(HttpStatus.EXPECTATION_FAILED.value());
				JSONObject jsonObject = new JSONObject();
				apiResponse_pojo.setResponseData(jsonObject);
			     return apiResponse_pojo;
			}
			else {
			if(user.getUserid()==userId) {
				if(user.getPin()==pin) {
					logger.warn("User Details is Verified");
					apiResponse_pojo.setMessage("User Details is Verified ");
				    apiResponse_pojo.setHttpStatus(HttpStatus.ACCEPTED.value());
				    JSONObject jsonObject = new JSONObject();
				    jsonObject.put("userId", userId);
				    jsonObject.put("pin", pin);
				    apiResponse_pojo.setResponseData(jsonObject);
				    return apiResponse_pojo;
			}
				else {
					logger.warn("user pin was wrong");
					apiResponse_pojo.setMessage("user pin was wrong");
				    apiResponse_pojo.setHttpStatus(HttpStatus.NOT_FOUND.value());
				    JSONObject jsonObject = new JSONObject();
				    jsonObject.put("pin was wrong", pin);
				    apiResponse_pojo.setResponseData(jsonObject);
				    return apiResponse_pojo;
				}
			}
			else if(user.getUserid()!=userId) {
				logger.warn("userid was wrong");
				apiResponse_pojo.setMessage("userid was wrong");
			    apiResponse_pojo.setHttpStatus(HttpStatus.NOT_FOUND.value());
			    JSONObject jsonObject = new JSONObject();
			    jsonObject.put("userId was wrong", userId);
			    apiResponse_pojo.setResponseData(jsonObject);
			    return apiResponse_pojo;
			}
			else {
				logger.warn("Datas are invalid");
				apiResponse_pojo.setMessage("Datas are invalid");
				apiResponse_pojo.setHttpStatus(HttpStatus.BAD_REQUEST.value());
				JSONObject jsonObject = new JSONObject();
				apiResponse_pojo.setResponseData(jsonObject);
			     return apiResponse_pojo;
			}
			}
			}
		catch (Exception e) {
			 logger.warn("Exception Occured");
		     apiResponse_pojo.setMessage("Exception Occured");
		     apiResponse_pojo.setHttpStatus(HttpStatus.BAD_GATEWAY.value());
		      return apiResponse_pojo;
		}
	}
	
}
