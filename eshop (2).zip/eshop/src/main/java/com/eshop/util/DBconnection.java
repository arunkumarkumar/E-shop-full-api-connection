package com.eshop.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.stereotype.Service;
@Service
public class DBconnection {
	private static BasicDataSource dataSource = null;
	 String Driver=null;
	    String Dburl=null;
	    String username=null;
	    String password=null;
		public BasicDataSource dbConnection() throws IOException {
			FileInputStream file = new FileInputStream("C:\\Users\\User\\Documents\\workspace-spring-tool-suite-4-4.17.0.RELEASE\\eshop.zip_expanded\\eshop\\src\\main\\resources\\application.properties");
			Properties property = new Properties();
			property.load(file);
			Driver=property.getProperty("spring.datasource.driver-class-name");
			Dburl=property.getProperty("spring.datasource.url");
			username=property.getProperty("spring.datasource.username");
			password=property.getProperty("spring.datasource.password");
			System.out.println("Property file worked");
			dataSource = new BasicDataSource();
			dataSource.setDriverClassName(Driver);
			dataSource.setUrl(Dburl);
			dataSource.setUsername(username);
			dataSource.setPassword(password);
			dataSource.setMinIdle(5);
			dataSource.setMaxIdle(10);
			dataSource.setMaxActive(25);
			return dataSource;
		}
	public Connection connection() throws SQLException {
		Connection connection = null;
		try {
			dataSource =new DBconnection().dbConnection();
			connection = dataSource.getConnection();
		} 
		catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("hello everyone");
		return connection;
	}

}
