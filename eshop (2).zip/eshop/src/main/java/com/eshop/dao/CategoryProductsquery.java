package com.eshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eshop.model.Categories;
import com.eshop.model.ProductDetails;
import com.eshop.util.DBconnection;
@Service
public class CategoryProductsquery {
	@Autowired
	DBconnection connect;
	Logger logger = LogManager.getLogger("Category Dao");
	public List<Categories> category(){
		List<Categories> categoriesList=new ArrayList<Categories>();
		try {
		String query = "select * from ARUNKUMAR_CATEGORIES";
		Connection userData = connect.connection();
		PreparedStatement preparestatement=userData.prepareStatement(query);
		ResultSet rs = preparestatement.executeQuery();
		while (rs.next()) {
			Categories categories=new Categories();
			categories.setCategories(rs.getString("Categories"));
			categories.setCategoryId(rs.getInt("CategoryId"));
			categoriesList.add(categories);
		}
		logger.info("data retrieved Successfully");
		if(categoriesList.size()>0) {
			logger.warn("ProductList has values");
			return categoriesList;
		}else {
			logger.warn("ProductList is empty");
			return null;
		}
	}
		catch (Exception e) {
			logger.fatal("SQLException : " + e.getLocalizedMessage());
			return null;
		}
		
	}
	public List<ProductDetails> products(String userCategory){
		logger.info("ProductDetails Dao");
		List<ProductDetails> productList = new ArrayList<ProductDetails>();
		try {
		String query = "select ProductId,ProductName,Quantity,ProductPrice from ARUNKUMAR_PRODUCTDETAILS  inner join  ARUNKUMAR_CATEGORIES  on ARUNKUMAR_PRODUCTDETAILS.CategoryId= ARUNKUMAR_CATEGORIES .CategoryId where Categories='"
				+ userCategory + "'";
		Connection userData = connect.connection();
		PreparedStatement preparestatement=userData.prepareStatement(query);
		ResultSet rs = preparestatement.executeQuery();
		while (rs.next()) {
			ProductDetails product=new ProductDetails();
			Categories categoriess=new Categories();
			categoriess.setCategories(userCategory);
			product.setId(rs.getInt("ProductId"));
			product.setName(rs.getString("ProductName"));
			product.setPrice(rs.getDouble("ProductPrice"));
			product.setQuantity(rs.getInt("Quantity"));
			product.setCategories(categoriess);
			productList.add(product);
	}
		logger.info("data retrieved Successfully");
		if(productList.size()>0) {
			logger.warn("ProductList has values");
			return productList;
		}else {
			logger.warn("ProductList is empty");
			return productList;
		}
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		

	}

}
