package com.eshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eshop.model.UserDetails;
import com.eshop.util.DBconnection;
@Service
public class UserandPinqueries {
		@Autowired
		DBconnection connect;
		Logger logger = LogManager.getLogger("UserandPin Login");
		public UserDetails getUserById(int userId) throws SQLException {
			logger.info("Existuser Dao");
			try {
			String query = "exec Sp_userDetail_getBy_Id '" + userId + "'";
			Connection userData = connect.connection();
			PreparedStatement preparestatement=userData.prepareStatement(query);
			ResultSet rs = preparestatement.executeQuery();
			UserDetails userDetails =new UserDetails();
			while (rs.next()) {
				userDetails.setUserid(rs.getInt("UserId"));
				userDetails.setPin(rs.getInt("Pin"));
			}
			logger.info("data retrieved Successfully");
				return userDetails;
		}
			catch (Exception e) {
				logger.fatal("SQLException : " + e.getLocalizedMessage());
				return null;
			}
		}
		public  boolean newUser(int userId,int pin) {
			logger.info("addnewuser Dao");
			try {
				String newUserdata="exec Sp_userDetail '" + userId + "','" + pin+ "','" + userId + "'";;
				Connection userData = connect.connection();
				PreparedStatement preparestatement=userData.prepareStatement(newUserdata);
				if (preparestatement.executeUpdate() > 0) {
					logger.info("data inserted successfully");
					return true;
				} else {
					logger.info("data insertion failed");
					return false;
				}
			}
			catch (Exception e) {
				logger.info("SQLException" + e.getLocalizedMessage());
				return false;
			}
			}
		
		}
		


