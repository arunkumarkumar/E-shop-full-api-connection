package com.eshop.dao;

import org.springframework.stereotype.Service;

import com.eshop.model.ProductDetails;

@Service
public class AddtoCartqueries {
    
	public String cartToAdd(int cartId, ProductDetails product, int quantity) {
		return null;
	}
}
